package org.repository;

public interface State {
    String cambiarIncidente();
}

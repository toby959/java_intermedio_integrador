package org.entity;


import javax.persistence.Entity;
import javax.persistence.Enumerated;



public enum Especialidad {


    SAP,WINDOWS,LINUX,TANGO,MAC;


}

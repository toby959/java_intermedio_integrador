package org.entity;

public enum Noti {
    EMAIL, WHATSAPP;
}
